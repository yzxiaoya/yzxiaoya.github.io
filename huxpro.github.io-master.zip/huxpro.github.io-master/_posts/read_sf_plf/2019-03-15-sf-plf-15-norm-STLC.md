---
title: "「SF-PLF」15 Norm"
subtitle: "Programming Language Foundations - Normalization of STLC"
layout: post
author: "Hux"
header-style: text
hidden: true
tags:
  - SF (软件基础)
  - PLF (编程语言基础)
  - Coq
  - 笔记
---

TBD
