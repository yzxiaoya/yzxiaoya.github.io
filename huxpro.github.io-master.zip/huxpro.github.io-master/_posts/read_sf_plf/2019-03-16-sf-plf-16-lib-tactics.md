---
title: "「SF-PLF」16 LibTactics"
subtitle: "Programming Language Foundations - A Collection of Handy General-Purpose Tactics"
layout: post
author: "Hux"
header-style: text
hidden: true
tags:
  - SF (软件基础)
  - PLF (编程语言基础)
  - Coq
  - 笔记
---

TBD
